#!/bin/bash

echo "TODO if deploying is needed"
