#!/bin/bash

apt-get update && apt-get install -y cmake git g++ clang zlib1g-dev valgrind
